﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS_Laba3
{
    class HashTable
    {
        Hashtable hashTable;
        public HashTable()
        {
            hashTable = new Hashtable();
        }

        
        public void PutPair(object key, object value)
        {
            if (hashTable.ContainsKey(key))
            {
                hashTable.Remove(key);
            }
            hashTable.Add(key, value);
        }

        public object GetValueByKey(object key)
        {
            if (hashTable.ContainsKey(key))
            {
                return hashTable[key];
            }
            else return null;
        }

    }
}
