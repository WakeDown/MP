﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS_Laba3
{
    class Program
    {
        static void Main(string[] args)
        {
            Test3Elements();
            Test2Elements();
            //Test10000Elements();
            Test1000In10000Elements();
            Console.ReadKey();
        }
        private static void Test1000In10000Elements()
        {
            HashTable hashTable = new HashTable();
            int size = 10000;
            initTable(hashTable, size);
            for(int i = 10000; i < 11000; i++)
            {
                if (hashTable.GetValueByKey(i) == null)
                    Console.WriteLine("Error!");
            }            
        }

        private static void Test10000Elements()
        {
            HashTable hashTable = new HashTable();
            int size = 10000;
            initTable(hashTable, size);
            printValue(hashTable, size);
        }

        private static void printValue(HashTable hashTable, int size)
        {
            for (int i = 1; i < size; i++)
            {
                Console.Write(hashTable.GetValueByKey(i).ToString() + " ");
            }
            Console.WriteLine();
        }

        private static void initTable(HashTable hashTable, int size)
        {
            for (int i = 0; i < size; i++)
            {
                hashTable.PutPair(i, ("Number " + i.ToString()));
            }
        }

        private static void Test2Elements()
        {
            HashTable hashTable = new HashTable();
            hashTable.PutPair(0, "Не рабит");
            hashTable.PutPair(0, "Все раотает, ты класный!");
            Console.Write(hashTable.GetValueByKey(0).ToString() + " ");
            Console.WriteLine();
        }

        private static void Test3Elements()
        {
            HashTable hashTable = new HashTable();
            hashTable.PutPair(0, "Zero");
            hashTable.PutPair(1, "One");
            hashTable.PutPair(2, "Two");
            printValue(hashTable, 3);
        }
    }
}
