﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS_Laba2
{
    class Program
    {

        static void Main(string[] args)
        {
            Test3Element();
            Test100Element();
            Test1000Element();
            Test0Element();
            Test1500000000Element();

            Console.ReadKey();
        }

        public static void Test1500000000Element()
        {
            Random random = new Random();
            int[] intArray = new int[1500000000];
            for (int k = 0; k < intArray.Length; k++)
            {
                intArray[k] = random.Next(0, 100);
            }
            QuickSort(intArray, 0, intArray.Length - 1);
            printArray(intArray);
        }

        public static void Test0Element()
        {
            int[] intArray = new int[] { };
            
            QuickSort(intArray, 0, intArray.Length - 1);
            printArray(intArray);
        }

        public static void Test1000Element()
        {
            Random random = new Random();
            int[] intArray = new int[1000];
            for (int k = 0; k < intArray.Length; k++)
            {
                intArray[k] = random.Next(0, 100);
            }
            QuickSort(intArray, 0, intArray.Length - 1);
            printArray(intArray);
        }

        public static void Test100Element()
        {
            Random random = new Random();
            int[] intArray = new int[100];
            int i = random.Next(0, 100);
            for (int k = 0; k < intArray.Length; k++)
            {
                intArray[k] = i;
            }            
            QuickSort(intArray, 0, intArray.Length - 1);
            printArray(intArray);
        }

        public static void Test3Element()
        {
            int[] intArray = new int[] { 7, 5, 8 };
            QuickSort(intArray, 0, intArray.Length - 1);
            printArray(intArray);
        }

        public static void QuickSort(int[] array, int a, int b)
        {
            if (a >= b)
            {
                return;
            }
            int pivot = partition(array, a, b);
            QuickSort(array, a, pivot - 1);
            QuickSort(array, pivot + 1, b);
        }

        private static int partition(int[] array, int a, int b)
        {
            int marker = a;
            for (int i = a; i <= b; i++)
            {
                if (array[i] <= array[b])
                {
                    int temp = array[marker];
                    array[marker] = array[i];
                    array[i] = temp;
                    marker += 1;
                }
            }
            return marker - 1;
        }

        private static void printArray(int[] array)
        {
            foreach (int i in array)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
        }
    }
}
