﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Standart_CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 100000;
            int middle = (b - a) / 2;
            String check;
            int count = 1;
            Console.WriteLine("Отвечайте на вопросы в формате 'y' или 'n'");
            while ((b - a) > 10)
            {
                Console.WriteLine("Вопрос № " + count);
                Console.WriteLine("Ваше число больше " + middle + "?");
                check = Console.ReadLine();
                switch (check)
                {
                    case "y":
                        a = middle;
                        middle += (b - a) / 2;
                        break;
                    case "n":
                        b = middle;
                        middle -= (b - a) / 2;
                        break;
                }
                count++;
            }
            check = "";
            while (true)
            {
                Console.WriteLine("Вопрос № " + count);
                Console.WriteLine("Ваше число " + a + "?");
                check = Console.ReadLine();
                switch (check)
                {
                    case "n":
                        a++;
                        count++;
                        break;
                    case "y":
                        Console.WriteLine("Вы загадали число : " + a);
                        Console.WriteLine("Число разгадано за " + count + " вопросов");
                        return;
                }
            }
        }
    }
}
