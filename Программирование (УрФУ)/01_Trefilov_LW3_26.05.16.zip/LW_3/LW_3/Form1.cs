﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LW_3
{
    public partial class Form1 : Form
    {
        private int a = 0;
        private int b = 100000;
        private int middle;
        private bool result;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((b - a) > 10)
            {
                a = middle;
                middle += (b - a)/2;
                label1.Text = ("Ваше число больше " + middle + "?");
            }
            else if (!result)
            {
                label1.Text = ("Ваше число " + a + "?");
                result = true;
            }
            if (result)
            {
                MessageBox.Show("Ваше число " + a);
                a = 0;
                b = 100000;
                middle = (b - a) / 2;
                label1.Text = ("Ваше число больше " + middle + "?");
                result = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            middle = (b - a) / 2;
            label1.Text = ("Ваше число больше " + middle + "?");
            result = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if ((b - a) > 10)
            {
                b = middle;
                middle -= (b - a) / 2;
                label1.Text = ("Ваше число больше " + middle + "?");
            }
            else
            {
                a++;
                label1.Text = ("Ваше число " + a + "?");
            }
        }
    }
}
