package com.company;
import java.util.ArrayList;
import java.util.Scanner;

public class Main
{

    public static void main(String[] args)
    {
        System.out.println("Телефонный справочник  ");
        System.out.println("Доступные вам команды: ");
        System.out.println("Добавить(или просто д) номер телефона имя  ");
        System.out.println("Удалить(у) номер телефона или имя  ");
        System.out.println("Найти(н) по номеру телефона или имени ");
        System.out.println("Выход(в) ");
        CommandLoop go  = new CommandLoop();
        go.DoLoop();
    }
}

 abstract class ICommand
{
    abstract public void Execute(CommandLoop CLP, String cmd);
}
 class CommandLoop
{
    ArrayList<data> list = new ArrayList<data>();
    void DoLoop()
    {
        Scanner sc= new Scanner(System.in);
        String str=sc.nextLine();

        CommandFactory cmd = new CommandFactory();
        cmd.function(str, this);

    }
}
 class data
{
    String Name;
    String PhoneNumber;
    data(String into)
    {
        String[] data = into.split(" ");
        Name = data[2];
        PhoneNumber = data[1];

    }
}

 class CommandFactory
{
     ICommand function(String str, CommandLoop CLP)
    {
        String[] cmd = str.split(" ");
        if (cmd[0].equals("Добавить") || cmd[0].equals("Найти") || cmd[0].equals("Удалить") || cmd[0].equals("Выход")|| cmd[0].equals("д") || cmd[0].equals("н") || cmd[0].equals("у") || cmd[0].equals("в"))
        {
            switch (cmd[0])
            {
                case ("Добавить"):
                    Add a = new Add();
                    a.Execute(CLP, str);
                    break;
                case ("д"):
                    Add add = new Add();
                    add.Execute(CLP, str);
                    break;
                case ("Удалить"):
                    Delete d = new Delete();
                    d.Execute(CLP, cmd[1]);
                    break;
                case ("у"):
                    Delete delete = new Delete();
                    delete.Execute(CLP, cmd[1]);
                    break;
                case ("Найти"):
                    Find f = new Find();
                    f.Execute(CLP, cmd[1]);
                    break;
                case ("н"):
                    Find find = new Find();
                    find.Execute(CLP, cmd[1]);
                    break;
                case ("Выход"):
                    Exit e = new Exit();
                    e.Execute(CLP, str);
                    break;
                case ("в"):
                    Exit exit = new Exit();
                    exit.Execute(CLP, str);
                    break;
            }
        }
        else
        {
            System.out.println("Такой команды не существует");
            CLP.DoLoop();
        }
        return null;
    }
}

class Add extends ICommand
        {
 public void Execute(CommandLoop CLP, String cmd)
        {
        CLP.list.add(new data(cmd));
        CLP.DoLoop();
        }
        }

class Delete extends ICommand
        {
public void Execute(CommandLoop CLP, String cmd)
        {
        ArrayList<data> temp = new ArrayList<data>();
        for (data  p :  CLP.list)
        {
        if (!p.Name.equals(cmd) && !p.PhoneNumber.equals(cmd))
        {
        temp.add(p);
        }
        }

        CLP.list = temp;
        CLP.DoLoop();
        }
        }

class Find extends ICommand
        {
public  void Execute(CommandLoop CLP, String cmd)
        {
        Boolean count = false;
        for(data p : CLP.list)
        {
        if (p.Name.equals(cmd)|| p.PhoneNumber.equals(cmd))
        {
        count = true;
        System.out.println(p.Name + " " + p.PhoneNumber);
        }
        }
        if (!count)
        {
            System.out.println("Нет таких контактов");
        }
        CLP.DoLoop();
        }
        }

class Exit extends ICommand
        {
public void Execute(CommandLoop CLP, String cmd) {}
        }







