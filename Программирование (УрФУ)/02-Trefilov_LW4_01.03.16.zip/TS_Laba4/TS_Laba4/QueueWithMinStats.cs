﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS_Laba4
{
    class QueueWithMinStats
    {
        Queue<int> data;

        public QueueWithMinStats(int size)
        {
            data = new Queue<int>(size);
        }

        public QueueWithMinStats()
        {
            data = new Queue<int>();
        }

        public void Enqueue(int value)
        {
            data.Enqueue(value);
        }

        public int Dequeue()
        {
            return Convert.ToInt32(data.Dequeue());
        }

        public int CurrentMiminum()
        {
            int[] dataArray = data.ToArray();
            int minimum = dataArray[dataArray.Length - 1];
            foreach (int i in dataArray)
            {
                if (minimum < i) minimum = i;
            }
            return minimum;
        }
    }
}
