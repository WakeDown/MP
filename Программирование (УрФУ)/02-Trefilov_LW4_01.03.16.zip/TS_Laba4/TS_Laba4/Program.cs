﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS_Laba4
{
    class Program
    {
        static void Main(string[] args)
        {
            Test1000Element();
            TestOne1000Times();

            Console.ReadKey();
        }

        private static void TestOne1000Times()
        {
            Random random = new Random();
            int element = new Random().Next();
            QueueWithMinStats qWMS = new QueueWithMinStats();
            for (int i = 0; i < 1000; i++)
            {
                qWMS.Enqueue(element);
                Console.WriteLine("Минимум: " + qWMS.CurrentMiminum().ToString() + " Вышел: " + qWMS.Dequeue().ToString());
            }
        }

        private static void Test1000Element()
        {
            Random random = new Random();
            QueueWithMinStats qWMS = new QueueWithMinStats(1000);
            for (int i = 0; i < 1000; i++)
            {
                qWMS.Enqueue(random.Next(-20, 70));
            }
            for (int i = 0; i < 1000; i++)
            {
                Console.WriteLine("Минимум: " + qWMS.CurrentMiminum().ToString() + " Вышел: " + qWMS.Dequeue().ToString());
            }
        }
    }
}
