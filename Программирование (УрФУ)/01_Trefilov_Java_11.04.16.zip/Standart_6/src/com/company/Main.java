package com.company;

import java.util.Objects;
import java.util.Scanner;

public class Main {
    static Scanner scanner;

    public static void main(String[] args) {
	    scanner  = new Scanner(System.in);
        new Main().guessTheNumber();
    }

    private void guessTheNumber(){
        int a = 0;
        int b = 100000;
        int middle = (b - a)/2;
        String check;
        int count = 1;
        System.out.println("Отвечайте на вопросы в формате 'y' или 'n'");
        while ((b - a) > 10){
            System.out.println("Вопрос № " + count);
            System.out.println("Ваше число больше " + middle + "?");
            check = scanner.nextLine();
            switch (check) {
                case "y":
                    a = middle;
                    middle += (b - a)/2;
                    break;
                case "n":
                    b = middle;
                    middle -= (b - a)/2;
                    break;
            }
            count++;
        }
        check = "";
        while (true){
            System.out.println("Вопрос № " + count);
            System.out.println("Ваше число " + a + "?");
            check = scanner.nextLine();
            switch (check){
                case "n":
                    a++;
                    count++;
                    break;
                case "y":
                    System.out.println("Вы загадали число : " + a);
                    System.out.println("Число разгадано за " + count + " вопросов");
                    return;
            }
        }
    }
}
