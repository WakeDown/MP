﻿using System;

namespace Лаб9_Стандарты
{    
    class Program
    {
        public static void Main()
        {
            Console.WriteLine("Телефонный справочник  ");
            Console.WriteLine("Доступные вам команды: ");
            Console.WriteLine("Добавить(или просто д) номер телефона имя  ");
            Console.WriteLine("Удалить(у) номер телефона или имя  ");
            Console.WriteLine("Найти(н) по номеру телефона или имени ");
            Console.WriteLine("Выход(в) ");
            CommandLoop go  = new CommandLoop();
            go.DoLoop();
        }
    }
}
