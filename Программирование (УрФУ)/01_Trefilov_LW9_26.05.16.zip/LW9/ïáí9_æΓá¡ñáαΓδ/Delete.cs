﻿using System;
using System.Collections.Generic;

namespace Лаб9_Стандарты
{
    class Delete : ICommand
    {
        public override void Execute(CommandLoop CLP, string cmd)
        {
            List<data> temp = new List<data>();
            foreach (data p in CLP.list)
            {
                if (p.Name != cmd && p.PhoneNumber != cmd)                
                    temp.Add(p);                
            }

            CLP.list = temp;
        }
    }
}
