﻿
namespace Лаб9_Стандарты
{
    public class data
    {
        public string Name;
        public string PhoneNumber;
        public data(string into)
        {
            string[] data = into.Split(' ');
            Name = data[2];
            PhoneNumber = data[1];

        }
    }
}
