﻿using System;

namespace Лаб9_Стандарты
{
    public class CommandFactory
    {
        public ICommand objectofcom;
        public CommandFactory(string str, CommandLoop loop)
        {
            objectofcom = function(str, loop);
        }

        public ICommand function(string str, CommandLoop CLP)
        {
            string[] cmd = str.Split(' ');
            if (cmd[0] == "Добавить" || cmd[0] == "Найти" || cmd[0] == "Удалить" || cmd[0] == "Выход" || cmd[0] == "д" || cmd[0] == "н" || cmd[0] == "у" || cmd[0] == "в")
            {
                switch (cmd[0])
                {
                    case ("Добавить"):
                        Add a = new Add();
                        a.Execute(CLP, str);
                        return a;
                    case ("д"):
                        Add add = new Add();
                        add.Execute(CLP, str);
                        return add;
                    case ("Удалить"):
                        Delete d = new Delete();
                        d.Execute(CLP, cmd[1]);
                        return d;
                    case ("у"):
                        Delete delete = new Delete();
                        delete.Execute(CLP, cmd[1]);
                        return delete;
                    case ("Найти"):
                        Find f = new Find();
                        f.Execute(CLP, cmd[1]);
                        return f;
                    case ("н"):
                        Find find = new Find();
                        find.Execute(CLP, cmd[1]);
                        return find;
                    case ("Выход"):
                        Exit e = new Exit();
                        e.Execute(CLP, str);
                        return e;
                    case ("в"):
                        Exit exit = new Exit();
                        exit.Execute(CLP, str);
                        return exit;
                }
            }
            else
            {
                Console.WriteLine("Такой команды не существует");
            }
            return null;
        }
    }
}
