﻿using NUnit.Framework;

namespace Лаб9_Стандарты
{
    [TestFixture]
    public class NUnit

    {
        [Test]
        public void Add()
        {
            CommandLoop loop = new CommandLoop();
            CommandFactory add1 = new CommandFactory("Добавить 02 Полиция", loop);
            CommandFactory add2 = new CommandFactory("Добавить 03 Скорая", loop);
            Assert.IsTrue(loop.list.Exists(x => x.PhoneNumber == "02" && x.Name == "Полиция"));
        }

        [Test]
        public void Find()
        {
            CommandLoop loop = new CommandLoop();
            CommandFactory add1 = new CommandFactory("Добавить 02 Полиция", loop);
            CommandFactory add2 = new CommandFactory("Добавить 03 Скорая", loop);
            CommandFactory find = new CommandFactory("Найти 02", loop);

            Assert.IsTrue(find.objectofcom.Final.Exists(x => x.PhoneNumber == "02" && x.Name == "Полиция"));
        }

        [Test]
        public void Delete()
        {
            CommandLoop loop = new CommandLoop();
            CommandFactory add1 = new CommandFactory("Добавить 02 Полиция", loop);
            CommandFactory add2 = new CommandFactory("Добавить 03 Скорая", loop);
            CommandFactory delete = new CommandFactory("Удалить 02", loop);
            
            Assert.IsFalse(loop.list.Exists(x => x.PhoneNumber == "02" && x.Name == "Полиция"));
            Assert.IsTrue(loop.list.Exists(x => x.PhoneNumber == "03" && x.Name == "Скорая"));
        }

        [Test]
        public void Exit()
        {
            CommandLoop loop = new CommandLoop();
            CommandFactory exit = new CommandFactory("Выход", loop);
            Assert.IsTrue(loop.exit == 1);
        }
    }
}
