﻿
namespace Лаб9_Стандарты
{
    class Add : ICommand
    {
        public override void Execute(CommandLoop CLP, string cmd)
        {
            CLP.list.Add(new data(cmd));
        }
    }
}
