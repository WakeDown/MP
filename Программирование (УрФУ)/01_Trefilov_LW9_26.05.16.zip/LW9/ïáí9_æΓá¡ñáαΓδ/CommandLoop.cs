﻿using System;
using System.Collections.Generic;

namespace Лаб9_Стандарты
{
    public class CommandLoop
    {        
       public List<data> list = new List<data>();
        public int exit = 0;
        public void DoLoop()
        {
            if (exit == 0)
            {
                string str = Console.ReadLine();
                CommandFactory cmd = new CommandFactory(str, this);
                //cmd.function(str, this);
                DoLoop();
            }
        }
    }    
}
