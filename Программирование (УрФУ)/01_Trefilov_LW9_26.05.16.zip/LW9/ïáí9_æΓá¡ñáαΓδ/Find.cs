﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Лаб9_Стандарты
{
    class Find : ICommand
    {
        public override void Execute(CommandLoop CLP, string cmd)
        {
            List<data> searched = new List<data>();
            searched = CLP.list.Where(x => (x.Name.Contains(cmd) || x.PhoneNumber.Contains(cmd))).ToList();
            if (searched.Count != 0)
                foreach (data result in searched)
                    Console.WriteLine(result.PhoneNumber + ' ' + result.Name);
        
             else
                Console.WriteLine("Нет таких контактов");
            Final = searched;
        }
    }
}

