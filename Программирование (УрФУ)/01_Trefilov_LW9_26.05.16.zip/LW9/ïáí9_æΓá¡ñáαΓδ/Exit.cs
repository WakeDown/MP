﻿
namespace Лаб9_Стандарты
{
    class Exit : ICommand
    {
        public override void Execute(CommandLoop CLP, string cmd)
        {
            CLP.exit = 1;
        }
    }
}
