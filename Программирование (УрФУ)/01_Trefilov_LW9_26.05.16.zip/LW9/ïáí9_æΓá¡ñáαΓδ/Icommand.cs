﻿
using System.Collections.Generic;

namespace Лаб9_Стандарты
{
    public abstract class ICommand
    {
        public List<data> Final = new List<data>();
        abstract public void Execute(CommandLoop CLP, string cmd);
    }
}