﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS_Laba1
{
    class BinarySearch
    {
        private int[] arrayInt;

        public BinarySearch(int[] array)
        {
            this.arrayInt = array;
        }

        public int find(int element)
        {
            int i = -1;
            if(arrayInt != null)
            {
                int low = 0;
                int hight = arrayInt.Length;
                int mid;
                while (low < hight)
                {
                    mid = (low + hight) >> 1;
                    if (element == arrayInt[mid])
                    {
                        i = mid;
                        break;
                    }
                    else
                    {
                        if (element < arrayInt[mid])  hight = mid;                        
                        else low = mid + 1;
                    }
               }
            }
            return i;
        }
    }
}
