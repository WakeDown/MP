﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS_Laba1
{
    class Program
    {
        public static int toBinarySearch(int[] array, int value)
        {
            BinarySearch bs = new BinarySearch(array);
            return bs.find(value);
        }

        static void Main(string[] args)
        {
            TestNegativeNumbers();
            TestNonExistentElement();
            TestSimpleNumbers();
            TestRepeatNumbers();
            TestEmptyNumbers();
            TestManyNumbers();

            Console.ReadKey();
        }

        private static void TestManyNumbers()
        {
            //Тестирование поиска в 100001 
            int[] biger = new int[100001];
            biger = initBiger(biger);
            if (toBinarySearch(biger, 3) != (biger.Length-1))
                Console.WriteLine("! Поиск не нашёл число 1 среди большого массива");
            else
                Console.WriteLine("Поиск вроде работает");
        }

        private static int[] initBiger(int[] biger)
        {
            Random random = new Random();
            for (int i = 0; i < biger.Length; i++)
            {
                biger[i] = random.Next(1, 4);
            }
            Array.Sort(biger);
            return biger;
        }

        private static void TestEmptyNumbers()
        {
            //Тестирование поиска в пустом массиве
            int[] empty = new int[6];
            if (toBinarySearch(empty, 5) >= 0)
                Console.WriteLine("! Поиск нашёл число 5 в пустом массиве");
            else
                Console.WriteLine("Поиск в пустом массиве работает корректно");
        }

        private static void TestRepeatNumbers()
        {
            //Тестирование поиска в повторяющихся числах
            int[] repeatNumbers = new[] { 1, 2, 2, 3, 4, 5, 6 };
            if (toBinarySearch(repeatNumbers, 2) != 1)
                Console.WriteLine("! Поиск не нашёл число 2 среди чисел {1, 2, 2, 3, 4, 5, 6}");
            else
                Console.WriteLine("Поиск среди повторяющихся чисел работает корректно");
        }

        private static void TestSimpleNumbers()
        {
            //Тестирование поиска в положительных числах
            int[] simpleNumbers = new[] { 1, 2, 3,  4, 5 };
            if (toBinarySearch(simpleNumbers, 4) != 3)
                Console.WriteLine("! Поиск не нашёл число 4 среди чисел {1, 2, 3, 4, 5}");
            else
                Console.WriteLine("Поиск среди положительный чисел работает корректно");
        }

        private static void TestNegativeNumbers()
        {
            //Тестирование поиска в отрицательных числах
            int[] negativeNumbers = new[] { -5, -4, -3, -2 };
            if (toBinarySearch(negativeNumbers, -3) != 2)
                Console.WriteLine("! Поиск не нашёл число -3 среди чисел {-5, -4, -3, -2}");
            else
                Console.WriteLine("Поиск среди отрицательных чисел работает корректно");
        }
        private static void TestNonExistentElement()
        {
            //Тестирование поиска отсутствующего элемента
            int[] negativeNumbers = new[] { -5, -4, -3, -2 };
            if (toBinarySearch(negativeNumbers, -1) >= 0)
                Console.WriteLine("! Поиск нашёл число -1 среди чисел {-5, -4, -3, -2}");
            else
                Console.WriteLine("Поиск отсутствующего элемента вернул корректный результат работает корректно");
        }

    }
}
